
# Customer Support Chatbot using NLP

## 📌 Objective
Build an AI-powered chatbot to handle customer queries using Natural Language Processing (NLP).

## 🧠 Features
- Intent recognition with custom NLP pipeline
- Response generation with trained classifier
- Streamlit-based web chat interface
- Flask backend for API support

## 🗂️ Structure
```
customer_support_chatbot/
├── app/                # Streamlit app
├── data/               # Intents, responses, and training data
├── models/             # Trained models and tokenizers
├── notebooks/          # Jupyter notebooks for experimentation
├── src/                # Training and backend code
├── requirements.txt
└── README.md
```

## 🚀 Running the Project
### Train the Bot
```bash
python src/train_chatbot.py
```

### Launch the Chat App
```bash
streamlit run app/app.py
```

## 📈 Real-World Usage
This chatbot can be deployed on websites or integrated into mobile apps to automate support and reduce manual load.
