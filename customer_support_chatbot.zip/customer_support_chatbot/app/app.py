
import streamlit as st
import numpy as np
import random
import nltk
import pickle
import tensorflow as tf
from nltk.stem import WordNetLemmatizer

nltk.download('punkt')
lemmatizer = WordNetLemmatizer()

model = tf.keras.models.load_model("models/chatbot_model.h5")
tokens = pickle.load(open("models/tokens.pkl", "rb"))
lbl_encoder = pickle.load(open("models/label_encoder.pkl", "rb"))
responses = pickle.load(open("models/responses.pkl", "rb"))

def clean_text(text):
    tokens_text = nltk.word_tokenize(text)
    tokens_text = [lemmatizer.lemmatize(word.lower()) for word in tokens_text]
    bag = [1 if word in tokens_text else 0 for word in tokens]
    return np.array([bag])

st.set_page_config(page_title="Customer Support Chatbot", layout="centered")
st.title("🤖 Customer Support Chatbot")

user_input = st.text_input("You:", "")

if user_input:
    inp = clean_text(user_input)
    result = model.predict(inp)
    tag = lbl_encoder.inverse_transform([np.argmax(result)])
    st.text_area("Bot:", random.choice(responses[tag[0]]), height=100)
