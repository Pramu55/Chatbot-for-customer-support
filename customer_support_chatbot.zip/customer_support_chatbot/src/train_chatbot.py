
import json
import random
import pickle
import numpy as np
import nltk
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import Adam
from nltk.stem import WordNetLemmatizer
import os

nltk.download('punkt')
nltk.download('wordnet')

lemmatizer = WordNetLemmatizer()

with open('data/intents.json') as file:
    data = json.load(file)

training_sentences = []
training_labels = []
labels = []
responses = {}

for intent in data['intents']:
    for pattern in intent['patterns']:
        training_sentences.append(pattern)
        training_labels.append(intent['tag'])
    responses[intent['tag']] = intent['responses']
    if intent['tag'] not in labels:
        labels.append(intent['tag'])

lbl_encoder = LabelEncoder()
lbl_encoder.fit(training_labels)
training_labels = lbl_encoder.transform(training_labels)

tokens = []
for sentence in training_sentences:
    words = nltk.word_tokenize(sentence)
    tokens.extend(words)

tokens = sorted(set([lemmatizer.lemmatize(w.lower()) for w in tokens if w.isalpha()]))

X_train = []
for sentence in training_sentences:
    bag = []
    sentence_words = nltk.word_tokenize(sentence)
    sentence_words = [lemmatizer.lemmatize(word.lower()) for word in sentence_words]
    for word in tokens:
        bag.append(1) if word in sentence_words else bag.append(0)
    X_train.append(bag)

X_train = np.array(X_train)
y_train = np.array(training_labels)

model = Sequential()
model.add(Dense(128, input_shape=(len(X_train[0]),), activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(64, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(len(labels), activation='softmax'))

model.compile(loss='sparse_categorical_crossentropy',
              optimizer=Adam(learning_rate=0.01), metrics=['accuracy'])

model.fit(X_train, y_train, epochs=200, verbose=1)

model.save('models/chatbot_model.h5')
pickle.dump(tokens, open('models/tokens.pkl', 'wb'))
pickle.dump(lbl_encoder, open('models/label_encoder.pkl', 'wb'))
pickle.dump(responses, open('models/responses.pkl', 'wb'))
